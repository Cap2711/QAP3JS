/***Question 1***/


function User(n, a) {
    this.name = n;
    this.age = a;
}

var userList = [];


function makeObj() {
    var name = document.getElementById('nameInput').value;
    var age = document.getElementById('ageInput').value;
    var user = new User(name, age);
    userList.push(user);
}


function displayObj() {
    var userListText = "";
    for (var i = 0; i < userList.length; i++) {
        userListText += "Name: " + userList[i].name + " Age: " + userList[i].age + "\n";
    }
    var userListDiv = document.createElement('div');
    userListDiv.textContent = userListText;
    var inputBox = document.querySelector('.inputBox');
    inputBox.appendChild(userListDiv);
}




/***Question 2***/

function showJSON() {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                var jsonResponse = JSON.parse(xhr.responseText);
                displayJSON(jsonResponse);
            } else {
                console.error("Failed to load JSON file");
            }
        }
    };
    xhr.open("GET", "data/user.json", true);
    xhr.send();
}

function displayJSON(jsonData) {
    var output = "";
    
    output += "<p>Name: " + jsonData.name + "</p>";
    output += "<p>Email: " + jsonData.email + "</p>";
    output += "<p>Company: " + jsonData.company + "</p>";
    output += "<p>Address: " + jsonData.address + "</p>"; 
   
    var question2Section = document.getElementById('question2');
    var answerDiv = question2Section.querySelector('.answer');
    answerDiv.innerHTML = output;
}




/*** Question 3***/

function showTodos() {
    fetch('https://jsonplaceholder.typicode.com/todos')
        .then(response => {
            if (!response.ok) {
                throw new Error('Failed to fetch todos');
            }
            return response.json();
        })
        .then(todos => {
            displayTodos(todos);
        })
        .catch(error => {
            console.error('Error fetching todos:', error);
        });
}

function displayTodos(todos) {
    var output = "<h3>Todos:</h3>";
    todos.forEach(todo => {
        output += `<p>${todo.title}</p>`;
    });
    
    var q3AnswerDiv = document.getElementById('q3Answer');
    q3AnswerDiv.innerHTML = output;
}
